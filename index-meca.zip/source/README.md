## Monitoring biodiversity for human, animal, and environmental health

This manuscript was made using Quarto and VS Code, following [this tutorial](https://quarto.org/docs/manuscripts/authoring/vscode.html).


